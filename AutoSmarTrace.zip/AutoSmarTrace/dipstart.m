addpath('C:\Program Files\DIPimage 2.9\common\dipimage');
dip_initialise;
